<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <aside class="main-sidebar main-sidebar-custom sidebar-dark-primary elevation-4">
            <a href="{{url('/')}}" class="brand-link">
                <img src="{{asset('build/assets/img/avatar4.png')}}" alt="AdminLTE Logo"
                    class="brand-image img-circle elevation-3">
                <span class="brand-text font-weight-light">Admin</span>
            </a>
            <nav class="mt-2">

                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <li class="nav-item {{\Request::segment(2) == 'dashboard' ? 'menu-open' :''}}">
                        <a href="{{route('admin.dashboard')}}"
                            class="nav-link {{\Request::segment(2) == 'dashboard' ? 'active' :''}}">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Dashboard
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                    </li>
                </ul>
                </li>
                </ul>
            </nav>
    </div>
    </aside>
    </div>
    </div>
</body>