@extends('admin.layouts.master')
@section('content')
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<div class="content-wrapper">
    <h5>Welcome User</h5> 
    <!-- Content Header (Page header) -->
    <div class="content-header"> 
           
            <div class="container">
                <div class="row">
                  <div class="col-md-3">
                    <h5>List 1</h5>
                    <ul class="list-group">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Morbi leo risus</li>
                        <li class="list-group-item">Porta ac consectetur ac</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                      </ul>
                  </div>
                 
                  <div class="container" id="lists-container">
                   
                    <!-- Existing lists will be appended here -->
                </div>
                   
                  <div class="col-md-3">
                    <h5>Create New List</h5>
                    <button id="create-list-btn">Create List</button>
                </div>

                   
                    
                    
                    
              </div>
        </div><!-- /.container-fluid -->
    </div>
    
    <!-- /.content -->
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    $(document).ready(function() {
        
        // Counter to track the number of created lists
        let listCounter = 1;

// Function to create a new list
function createList() {
    const listHtml = `
        <div class="col-md-3" id="list-${listCounter}">
            <h5>List ${listCounter}</h5>
            <ul class="list-group" id="task-list-${listCounter}">
                <input type="hidden" name="name" value="${listCounter}"> 
                <!-- Initial task input field with checkbox -->
                <li class="list-group-item">
                    <input type="checkbox" name="complete" class="complete-checkbox">
                    <input type="text" name="name" placeholder="Task" class="task-input">
                </li>
            </ul>
            <button class="add-task-btn">Add Task</button>
            <button class="save-list-btn">Save List</button>
        </div>
    `;

    // Append the new list to the container
    $("#lists-container").append(listHtml);

    // Increment the counter for the next list
    listCounter++;
}

// Event listener for the "Create List" button
$("#create-list-btn").on("click", function() {
    createList();
});

// Event listener for the "Save List" button inside each list
$(document).on("click", ".save-list-btn", function() {
    const listId = $(this).parent().attr("id");
    const tasks = [];

    // Collect tasks from the list
    $(`#${listId} ul.list-group li`).each(function() {
        const taskInput = $(this).find("input.task-input");
        const completeCheckbox = $(this).find("input.complete-checkbox");

        tasks.push({
            task: taskInput.val(),
            complete: completeCheckbox.prop("checked")
        });
    });

    // Send data to the server for storage
    saveListToDatabase(listId, tasks);
});

// Function to save list to the database using AJAX
function saveListToDatabase(listId, tasks) {
    $.ajax({
        url: '/api/dashboard', // Replace with your actual API endpoint
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            list_id: listId,
            tasks: tasks
        }),
        success: function(response) {
            console.log('List saved successfully:', response);
        },
        error: function(error) {
            console.error('Error saving list:', error);
        }
    });
}

    
        // Event listener for the "Add Task" button inside each list
        $(document).on("click", ".add-task-btn", function() {
            const listId = $(this).parent().attr("id");
            const taskList = $(`#${listId} ul.list-group`);
            const taskInput = $('<li class="list-group-item"><input type="checkbox" name="complete" class="complete-checkbox"><input type="text" name="name" placeholder="Task" class="task-input"></li>');
            taskList.append(taskInput);
        });
    
        // Event listener for the "Save List" button inside each list
        $(document).on("click", ".save-list-btn", function() {
            const listId = $(this).parent().attr("id");
            const tasks = [];
            $(`#${listId} ul.list-group li`).each(function() {
                const taskInput = $(this).find("input.task-input");
                const completeCheckbox = $(this).find("input.complete-checkbox");
    
                if (!completeCheckbox.prop("checked")) {
                    tasks.push({
                        task: taskInput.val(),
                        complete: completeCheckbox.prop("checked")
                    });
                }
            });
    
            // Assuming you have a function to save tasks to the database
            saveTasksToDatabase(listId, tasks);
        });
    
        // Event listener for the checkboxes to remove tasks
        $(document).on("change", ".complete-checkbox", function() {
            if ($(this).prop("checked")) {
                // Remove the corresponding task when the checkbox is checked
                $(this).closest("li").remove();
            }
        });
    
        // Function to save tasks to the database (placeholder function)
        function saveTasksToDatabase(listId, tasks) {
            // Implement your code to save tasks to the database here
            console.log(`List ${listId} tasks:`, tasks);
            // You can send tasks to the server here for further processing
        }
    });
    </script>

@endsection



