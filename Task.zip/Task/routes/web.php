<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\ListController;
use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::middleware(['auth'])->group(function () {
    Route::prefix('admin')->group(function () {
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
        Route::post('/dashboard', [AdminDashboardController::class, 'store']);
        Route::resource('lists', ListController::class);
        Route::resource('tasks', TaskController::class);
        Route::get('/logout', [AdminController::class, 'logout'])->name('admin.logout');
        });
});

