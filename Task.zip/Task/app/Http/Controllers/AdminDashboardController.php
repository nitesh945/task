<?php

namespace App\Http\Controllers;

use App\Models\UserList;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
    public function index(){
        $lists = UserList::all();
        return view('admin.dashboard.index', compact('lists'));
    }


    public function store(Request $request)
{
    $list = UserList::create($request->all());
    return response()->json($list, 201);
}
}
