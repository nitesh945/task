<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Lead;
use App\Models\UserAddress;
use App\Models\UserInformation;
use App\Models\UserPayment;
use DB;
use Auth;

class AdminController extends Controller
{
//     public function __construct()
// {
//     $this->middleware('auth');
//     $this->middleware('admin')->only(['index']);
//     $this->middleware('manager')->only(['index']);
//     $this->middleware('partner')->only(['index']);
// }
    public function index()
    {
        $users = User::where('role','!=','admin')->get();
        return view('admin.index', compact('users'));
    }

    public function showManagers()
    {  
        // $abc = User::get();
        // $abc = UserInformation::with('user')->get();
        // $abc = UserAddress::with('user_info')->get();
        // $abc = UserPayment::with('user_address')->get();
        
        // Fetch users
        $users = User::with('info.addresses.payments')->get();
      dd($users);
// $userInformation = UserInformation::with('user')->whereIn('user_id', $users->pluck('id'))->get();
// dd($userInformation);
// $userAddresses = UserAddress::with('user_info')->whereIn('user_id', $users->pluck('id'))->get();

// $userPayments = UserPayment::with('user_address')->whereIn('user_address_id', $userAddresses->pluck('id'))->get();



        $managers = User::where('role', 'manager')->get();
        return view('admin.managers.index', compact('managers'));
    }

    public function assignPartnersView(){
        
        $managers = User::where('role','manager')->get();
        $partners = User::where('role','partner')->get();
        return view('admin.partners.assign',compact('managers','partners'));
    }

    public function assignPartner(Request $request)
{
    $this->validate($request, [
        'manager_id' => 'required|exists:users,id,role,manager',
        'partner_id' => 'required|exists:users,id,role,partner',
    ]);

    $partner = User::findOrFail($request->input('partner_id'));
    $partner->manager_id = $request->manager_id;
    
    if ($partner->save()) {
        Lead::where('partner_id', $partner->id)
            ->update(['manager_id' => $request->manager_id]);

        return redirect()->back()->with('success', 'Partner assigned to manager successfully.');
    }

    return redirect()->back()->with('error', 'Failed to assign partner to manager.');
}


    public function showPartners()
    {
        $partners = User::where('role', 'partner')->get();
        return view('admin.partners.index', compact('partners'));
    }

    public function createManager()
    {   
        $managerId = '';
        return view('admin.managers.CreateOrUpdate',compact('managerId'));
    }

    public function storeManager(Request $request)
    {
       
        $this->validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
           
        ]);

        DB::beginTransaction();

        try {
        $manager = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => bcrypt($request->input('password')),
            'role' => 'manager',
            
        ]);
        DB::commit();
        return redirect('admin/managers')->with(['message' => 'Manager added successfully.']);
    } catch (\Exception $e) {
        DB::rollback();
        return back()->withError($e->getMessage())->withInput();
    }
        
        //return redirect()->route('admin.managers.index');
    }

    public function createPartner()
    {
        $partnerId = '';
        return view('admin.partners.CreateOrUpdate',compact('partnerId'));
    }

    public function storePartner(Request $request)
    {
       
        $this->validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            
        ]);

        DB::beginTransaction();

        try {
        $partner = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => bcrypt($request->input('password')),
            'role' => 'partner',
            
        ]);
        DB::commit();
        return redirect('admin/partners')->with(['message' => 'Partner added successfully.']);
    } catch (\Exception $e) {
        DB::rollback();
        return back()->withError($e->getMessage())->withInput();
    }
    
        //return redirect()->route('admin.partners.index');
    }

    public function editManager(string $id){

        $result = User::find($id);
        $managerId = $result->id;
        return view('admin.managers.CreateOrUpdate',compact('result','managerId'));

    }

    public function editPartner(string $id){

        $result = User::find($id);
        $partnerId = $result->id;
        return view('admin.partners.CreateOrUpdate',compact('result','partnerId'));

    }


    public function updateManager(Request $request, string $id)
    {  
        $this->validate($request, [
            'name'   => 'required',
            'email'   => 'required',
            //'password' => 'required'
        ]);

        $manager = User::find($request->id);
        $manager->name = $request->name;
        $manager->email = $request->email;
        if ($request->filled('password')) {
            $manager->password = bcrypt($request->input('password'));
        }
        $manager->save();

        if ($manager->save()) {
            return redirect('admin/managers')->with('message', 'Manager successfully updated.');
        } else {
            DB::rollback();
            return back()->withError($e->getMessage())->withInput();
        }
    }


    public function updatePartner(Request $request, string $id)
    {  
        $this->validate($request, [
            'name'   => 'required',
            'email'   => 'required',
            //'password' => 'required'
        ]);

        $partner = User::find($request->id);
        $partner->name = $request->name;
        $partner->email = $request->email;
        if ($request->filled('password')) {
            $manager->password = bcrypt($request->input('password'));
        }
        $partner->save();

        if ($partner->save()) {
            return redirect('admin/partners')->with('message', 'partner successfully updated.');
        } else {
            DB::rollback();
            return back()->withError($e->getMessage())->withInput();
        }
    }


    public function destroyManager($id)
    {
        DB::beginTransaction();

        try {
            $manager = User::find($id);
            $manager->delete();
            DB::commit();
            return redirect()->back()->with(['message' => 'Manager successfully deleted.']);
        } catch (\Exception $e) {
            DB::rollback();
            return back()->withError($e->getMessage())->withInput();
        }
    }

    public function destroyPartner($id)
    {
        DB::beginTransaction();

        try {
            $partner = User::find($id);
            $partner->delete();
            DB::commit();
            return redirect()->back()->with(['message' => 'partner successfully deleted.']);
        } catch (\Exception $e) {
            DB::rollback();
            return back()->withError($e->getMessage())->withInput();
        }
    }


    public function logout(Request $request)
    {
         Auth::logout(); 
         return redirect('/login');
        //Auth::guard('user')->logout();
        //Auth::logout();
        //$request->session()->invalidate();
        //$request->session()->regenerateToken();
        //return redirect()->route('/login');
       
    }

}


