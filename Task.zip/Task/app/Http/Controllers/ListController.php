<?php

// app/Http/Controllers/ListController.php
namespace App\Http\Controllers;

use App\Models\UserList;
use Illuminate\Http\Request;

class ListController extends Controller
{
    public function index()
    {
        $lists = UserList::all();
        return view('lists.index', compact('lists'));
    }

    public function create()
    {
        return view('lists.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        UserList::create(['name' => $request->name]);

        return redirect()->route('lists.index')->with('success', 'List created successfully');
    }
}

